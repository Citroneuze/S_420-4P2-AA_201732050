//package org.calma.ui.s_4204p2aa_201732050.ETC_SPACE_INVADER.Observer;
//
//public interface ObserverCollision {
//    public void alarme();
//}
