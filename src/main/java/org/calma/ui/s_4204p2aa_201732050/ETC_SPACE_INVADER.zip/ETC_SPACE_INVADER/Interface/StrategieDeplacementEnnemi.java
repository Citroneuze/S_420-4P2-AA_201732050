package org.calma.ui.s_4204p2aa_201732050.ETC_SPACE_INVADER.Interface;



import org.calma.ui.s_4204p2aa_201732050.ETC_SPACE_INVADER.Vaiseau.EnnemiSpaceShip;
import org.newdawn.slick.GameContainer;

public interface StrategieDeplacementEnnemi {
    void deplacer(EnnemiSpaceShip ennemi, GameContainer gc);
}

